class UserXPValue {
  static int loginXP = 2;
  static int registerXP = 50;
  static int voteXP = 1;
  static int postXP = 10;
  static int remixXP = 15;
  static int reactionXP = 3;
  static int commentXP = 5;
  static int replyXP = 5;
  static int followXP = 2;
  static int taggingXP = 5;
  static int mentionXP = 5;
  static int shareOutsideXP = 20;
}
