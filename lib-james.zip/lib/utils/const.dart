import 'dart:math';
import 'package:insoblok/utils/image.dart';
import 'package:flutter/material.dart';

const kDBName = 'insoblok.db';

const kMetamaskApiKey = '615f56a659f5443b90abc4e1fc8a7755';
const kMetamaskApiUrl =
    'https://mainnet.infura.io/v3/615f56a659f5443b90abc4e1fc8a7755';
const kMetamaskSecretKey =
    '1FQzJGgUJadmOhZcwyHdezJG0fI6r0gSv8FoFDTHWEAJkZaNNJ7Qlw';
const kEthereumRpcUrl = 'https://mainnet.infura.io/v3/$kMetamaskApiKey';

const kDefaultIpAddress = '210.137.192.3';
const kDefaultLat = '34.916438';
const kDefaultLon = '137.215438';

const kPerigonApiKey = '8f022782-50f7-4e15-8485-7c913f9e6f09';
const kPrivacyUrl = 'https://www.insoblokai.io/privacy-policy';
const kRecevierEmail = 'info@insoblokai.io';

const kDebugEmail = 'kenta@insoblokai.io';
const kDebugPassword = 'Kenta123!@#';

const kDefaultVTOEmail = "vikashaitcrypto@gmail.com";
const kDefaultVTOPassword = "Fashion@267";

const kMVPTestingMode = true;

const kReownProjectID = 'b53edeab61d811385b99d22a2a8cdd39';

const kNewsDataCryptoApiKey = 'pub_e18b6ab1a4fd45ccaaf5404ff0fe2ca0';
const kKieAIApiKey = '023c12d4e0056edbce4b8ff0d2a7f616';
const kFashnAIApiKey = 'fa-eBz6zcFnI8N6-mbkhCdUWIICUuBYWtYPblFf5';
const VIMEO_CLIENT_ID = 'c6e5b5bcfef918538cf2f139281072e120b57f2d';
const VIMEO_CLIENT_SECRET =
    'MjB+ycRLuFJnK9nhAHyCI65viQIQ8Q3UlE3CZPEjCjzlE6ANOjnVFFREukx9TIPbTbsbrce4obx0Yv5c9sf5r1BmAbU0kA7GnuIdEAWyrmpzBgX9ZuNk1kaAz8wWsE2k';
// const VIMEO_ACCESS_TOKEN = '7f380ffb91d702aa9cdba204e3e44569';
// const VIMEO_ACCESS_TOKEN = '5f93bae0dc1ff5587359fe3d1eb1fe81';
const VIMEO_ACCESS_TOKEN = '878f243aba8c118ee174d8918c58ed03';

const WISITIA_ACCESS_TOKEN =
    '02c7dac76deab8e3fdf8116e4d3572313207c0e048d48df281bf6a3fbd7bf88a';

const kAvatarSize = 60.0;

const DEEPAR_ANDROID_KEY =
    'e332c29bc405ace300d31b356060ee1b3604fe96e7ef3cb47d3f16d7fedd9e626f00f88acb70aedd';
const DEEPAR_IOS_KEY =
    '5dd0e1f500e57133ea528acbc4fba42d38c80229590d1fdab9dfcb07145c0f9ccb9bb2bcc5bc5262';

const CDN_CLOUD_NAME = 'drlpximxi';
const CDN_API_KEY = '628114573592919';
const CDN_API_SECRET = 'P1283tVq_0pfNlVsSFbzpZgqhsI';
const CDN_UPLOAD_PRESET = 'insoblokai';

const CDN_IMG_UPLOAD_MAX_LIMIT = 10 * 1024 * 1024;
const CDN_VIDEO_UPLOAD_MAX_LIMIT = 100 * 1024 * 1024;

const INFURA_PROJECT_ID = "cd21ca163b6547678b4753d4f8a3a73a";

const ETHEREUM_WS_URL = "wss://mainnet.infura.io/ws/v3";
const ETHEREUM_RPC_URL = "https://mainnet.infura.io/v3";
const ETHERSCAN_URL = "https://api.etherscan.io/v2/api/";
const ETHERSCAN_API_KEY = "9BS41GK9SSWS6MMS3Y6QMUCTCJZE6RPX8T";
const SEPOLIA_WS_URL = "wss://sepolia.infura.io/ws/v3";
const SEPOLIA_RPC_URL = "https://sepolia.infura.io/v3";
const INSOBLOK_WALLET_URL = "https://insoblok-wallet-backend.ue.r.appspot.com";

final LAMPORTS_PER_SOL = pow(10, 9);

enum BlockchainNetwork {
  ethereumMainnet,
  ethereumSepolia,
  bnbMainnet,
  bnbTestnet,
  solanaMainnet,
  solanaDevnet,
  solanaTestnet,
}

final kWalletTokenList = [
  {
    "id": 0,
    'chain': 'xp',
    'chainId': 0,
    'name': "xp",
    'short_name': "XP",
    'icon': AIImages.icUserXP,
    "displayName": "XP",
    "test": false,
    "token_address": "",
    'scanUrl': "",
    "coingecko_id": "inso_xp",
    "binance_id": "",
  },
  {
    "id": 1,
    'chain': 'insoblok',
    'chainId': 11155111,
    'name': 'inso',
    'short_name': 'INSO',
    'icon': AIImages.icCoinInso,
    "displayName": "InSoBlok",
    "test": false,
    "token_address": "0x724c5ECcB208992747E30ea6BB5E558F8bF770d5",
    'scanUrl': "https://sepolia.etherscan.io/tx",
    "coingecko_id": "insoblok",
    "binance_id": "",
  },
  {
    "id": 2,
    'chain': 'usdt',
    'chainId': 0,
    'name': 'usdt',
    'short_name': 'USDT',
    'icon': AIImages.icCoinUsdt,
    "displayName": "USDT",
    "test": false,
    "token_address": "",
    'scanUrl': "https://etherscan.io/tx",
    "coingecko_id": "tether",
    "binance_id": "",
  },
  {
    "id": 3,
    'chain': 'xrp',
    'chainId': 0,
    'name': 'xrp',
    'short_name': 'XRP',
    'icon': AIImages.icCoinXrp,
    "displayName": "XRP",
    "test": false,
    "token_address": "",
    'scanUrl': "https://sepolia.etherscan.io/tx",
    "coingecko_id": "ripple",
    "binance_id": "xrpusdt",
  },
  {
    "id": 4,
    'chain': 'ethereum',
    'chainId': 1,
    'name': "eth",
    'short_name': "ETH",
    'icon': AIImages.icCoinEther,
    "displayName": "Ethereum Mainnet",
    "test": false,
    "token_address": "",
    'scanUrl': "https://etherscan.io/tx",
    "coingecko_id": "ethereum",
    "binance_id": "ethusdt",
  },
  {
    "id": 5,
    'chain': 'sepolia',
    'chainId': 11155111,
    'name': "seth",
    'short_name': "SETH",
    'icon': AIImages.icCoinEther,
    "displayName": "Sepolia Testnet",
    "test": true,
    "token_address": "",
    'scanUrl': "https://sepolia.etherscan.io/tx",
    "coingecko_id": "sepolia",
    "binance_id": "",
  },
];

final kAvailableNetworks = ["ethereum", "binance-smart-chain", "solana"];

const kWalletActionList = [
  // {'name': 'Buy', 'icon': Icons.add},
  {'name': 'Send', 'icon': Icons.arrow_upward},
  {'name': 'Receive', 'icon': Icons.arrow_downward},
  {'name': 'Swap', 'icon': Icons.swap_horiz},
  // {'name': 'Bridge', 'icon': Icons.link},
];

String chains = kWalletTokenList
    .where(
      (token) =>
          token['binance_id'] != null &&
          token['binance_id']!.toString().isNotEmpty,
    )
    .map((token) => '"' + token['binance_id']!.toString().toUpperCase() + '"')
    .join(',');
final TOKEN_PRICES_URL =
    "https://api.binance.us/api/v3/ticker/24hr?symbols=[$chains]";
// enum FileType { image, video, audio, other }
final TOKEN_LIST_COINGECKO_URL =
    "https://api.coingecko.com/api/v3/coins/list?include_platform=true";

final TOKEN_SEARCH_COINGECKO_URL =
    "https://api.coingecko.com/api/v3/search?query=";

final TOKEN_MARKETS_COINGECKO_URL =
    "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&sparkline=true&price_change_percentage=24h&ids=";
final TOKEN_DETAILS_COINGECKO_URL = "https://api.coingecko.com/api/v3/coins";
final TOKEN_SPARKLINES_COINGECKO_URL =
    "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&sparkline=true&price_change_percentage=1h,24h,7d,30d&ids=";

const telemetryAPIKey = "S3PiqnfLCUvgY92KcJbcXxaE";
const telemetryBaseUrl = "https://s1385328.eu-nbg-2.betterstackdata.com";

// final GOOGLE_API_KEY = "AIzaSyAN4xG1SxbgazfmqjxG84yX4Il1DV01Jxc";
final GOOGLE_API_KEY = "AIzaSyCq_c9z0aNOUEi5JnEh8VOPgMMN51NyT1o";
final TOKEN_METRICS_API_KEY = "tm-e387a0b2-32f8-47df-ae2e-d5c20f8af1f0";
final COIN_MARKET_CAP_API_KEY = "e91affab-6ec2-456c-8ea2-04a986b39082";

final LEADER_BOARD_DISPLAY_LENGTH = 50;

final AVATAR_GENERATION_SERVER_ENDPOINT = "http://108.61.119.241:8000";
final AVATAR_VIDEO_GENERATION_SERVER_ENDPOINT = "http://149.28.120.47:8000";

final kUserAvatarSize = 48.0;

final GET_IMG_AI_ENDPOINT =
    "https://api.getimg.ai/v1/stable-diffusion/image-to-image";
final GET_IMG_AI_API_KEY =
    "key-EPMZ5TnkubvMONsvSwyi34lb6z7vQoqR0p6nYZRfkdHL0PK2Rie4mw0f0XvftDutBYnmlglwyUNQBshG9mdG0m49Wh95ktC";

final RUNWARE_API_KEY = "RJzKblOYOLrCRMXoVdFoOr3cEpyAxXYT";
// Runware account (for reference/ops)
final RUNWARE_USERNAME = "vikash@insoblokai.io";
final RUNWARE_PASSWORD = "Fashion@267";
final RUNWARE_BASE_URL = "https://api.runware.ai";