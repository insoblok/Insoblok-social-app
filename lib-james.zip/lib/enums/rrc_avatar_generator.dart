enum SourceType {
  assets,
  file,
  network,
  raw
}